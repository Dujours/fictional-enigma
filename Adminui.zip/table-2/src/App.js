import React from "react";
import "./styles.css";
import HomePage from "./component/HomePage";
import "./component/HomePage.css";

export default function App() {
  return (
    <div className="App">
      <HomePage />
    </div>
  );
}
